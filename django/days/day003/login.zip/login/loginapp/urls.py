
from django.urls import path

from . import views


urlpatterns = [
    path('getragiserpage/',views.GetRagisterpage),
    path('getloginpage/', views.GetLoginpage),
]