from django.shortcuts import render

from .models import userinfo

# Create your views here.
def GetRagisterpage(request):
    return render(request,'ragitration.html')

def GetLoginpage(request):
    return render(request,'login.html')