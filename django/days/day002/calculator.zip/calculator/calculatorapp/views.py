from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.

def Greet(request):
    return HttpResponse ("Good MOrning ")

def GetAdditionPage(request):
    return render (request,'Addition.html')

def Addition(request):
    num1 = request.GET['num1']
    num2 = request.GET['num2']

    add = int(num1) + int(num2)

    return render (request,'Addition.html', {"num1":num1,"num2":num2, "ans":add, 'msg':'addition operation done !!!'})