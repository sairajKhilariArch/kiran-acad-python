from django.urls import path 

from . import views

urlpatterns = [
 path('greet/', views.Greet),

            # GET page urls

 path('getaddpage/', views.GetAdditionPage),

            # airthamatic operation Urls

path('addition/', views.Addition)

]