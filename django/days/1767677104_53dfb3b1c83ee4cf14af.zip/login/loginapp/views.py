from django.shortcuts import render
from django.db import connection

from .models import userinfo

# Create your views here.
def GetRagisterpage(request):
    return render(request,'ragitration.html')

def GetLoginpage(request):
    return render(request,'login.html')

def getUsercurdPage(request):
    return render (request,'usercurd.html')

def GetshowallPage(request):
    userdb = userinfo.objects.all()
    return render(request,'showall.html',{'userdb':userdb})

def GetBasePage(request):
    return render(request,'base.html')

def RegisterUSer(request):
    username = request.GET['username']
    password = request.GET['password']
    mobno = request.GET['mobno']

    userinfo.objects.create(username = username, password = password, mob_no = mobno)

    return render (request,'login.html',{'msg': 'user ragister successfully'})


def LoginUser(request):
    username = request.GET['username']
    password = request.GET['password']   

    request.session['username'] = username

    userdb = userinfo.objects.get(username = username)

    if userdb.password == password :
        return render (request,'home.html', {'msg' : 'user login successfully !!!'})
    
    else  :
        return render (request,'login.html',{'msg': 'incorrect username and password'})
    
def ADD_User(request):
    username = request.GET['username']
    password = request.GET['password']
    mobno = request.GET['mobno']

    userinfo.objects.create(username = username, password = password, mob_no = mobno)
    print(connection.queries)

    return render (request,'usercurd.html',{'msg': 'user Add successfully'})


def ShowUser(request):
    username = request.GET['username']
    userdb = userinfo.objects.get(username = username)
    print(connection.queries)
    return render (request,'usercurd.html',{'userdb': userdb})

def UpdateUser(request):
    username = request.GET['username']
    userdb = userinfo.objects.filter(username = username)

    userdb.update(password =request.GET['password'], mob_no = request.GET['mobno'])
    print(connection.queries)

    return render (request,'usercurd.html',{'userdb': userdb, 'msg': 'user update successfully'})

def DeleteUser(request):
    username = request.GET['username']
    userdb = userinfo.objects.filter(username = username).delete()
    print(connection.queries)
    return render (request,'usercurd.html',{'userdb': userdb, 'msg': 'user delete successfully'})

def DeleteUserShowAll(request):
    username = request.GET['username']
    userinfo.objects.filter(username = username).delete()

    userdb = userinfo.objects.all()

  
    return render(request,'showall.html',{'userdb':userdb})