
from django.urls import path

from . import views


urlpatterns = [

    path('',views.GetBasePage),

    path('getragiserpage/',views.GetRagisterpage),
    path('getloginpage/', views.GetLoginpage),
    path('getusercurdpage/', views.getUsercurdPage),
    path('getshowallpage/', views.GetshowallPage),


    path('ragisteruser/', views.RegisterUSer),
    path('loginuser/', views.LoginUser),


    path('adduser/',views.ADD_User),
    path('showuser/', views.ShowUser),
    path('upadteuser/', views.UpdateUser),
    path('deleteuser/', views.DeleteUser),

    path('deleteshowall/', views.DeleteUserShowAll),
]