from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.

def index(requrest):
   return HttpResponse ("This is my First Django Application")