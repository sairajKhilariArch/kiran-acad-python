import mysql.connector

conn = mysql.connector.connect(
    host = "localhost",
    user = "root",
    passwd = 'root',
    port = 3306,
    database = '1293db' 
)
print("database connection create sucessfully !!!!!")


cu = conn.cursor()

# dname  =  input("Enter database name : ")
# data = (dname)
# cdata = f'create database if not exists {dname}'

# cu.execute(cdata)

# print("database create sucessfully !!!!!")

# cu.execute('show databases')

# cu.execute("use 1293db")

cu.execute("use 1293db")

tname = input("enter table name : ")
tid = int(input("enter tid : "))

select = "select * from {} where tid = %s".format(tname)

# data1 = (tname , tid )

# cu.execute(select)
# print(cu.fetchone())

# tname1 = input("enter table name : ")
# col1 = input("enter cloname 1 : ")
# col2 = input("enter colname 2 : ")

# cretable = f"create table {tname1} ({col1} int , {col2} varchar(250))"

# cu.execute(cretable)


# rid = int(input("enter rid : "))
# rname = input("enter rname : ")

# idata = "insert into ritik (rid, rname) values (%s,%s)"
# data = [(rid , rname,)]

# cu.executemany(idata , data)

# conn.commit()

# print("data insert successfully")
tname = input("enter table name :  " )
rid = int(input("enter rid  : "))
urid = int(input("enter update rid : "))
colname = input("enter column name : ")

udata = "update {0} set {1} = {2} where {1} = %s".format(tname,colname,urid,)

data1 = [(rid,)]
cu.executemany(udata,data1)

conn.commit()

print("data Update successfully")


str1 = f"use {%s}"