#  pip install mysql-connector
#  pip install mysql-connector-python
#  pip install--upgrade mysql-connector
# pip install pymysql

# pip list

import mysql.connector

# conn = mysql.connector.connect(
#     host = "localhost" ,
#     user ="root" ,
#     passwd ="root" ,
#     port =3306 , 
    # name="1293DB"   # optional
# )



import pymysql
conn1 = pymysql.connect(
     host = "localhost" ,
    user ="root" ,
    password ="root" ,
    port =3306 , 
    database="1293DB"
)

print("database connection sucessfully")

cu = conn1.cursor()

sdata = "show databases"

# print(cu.execute(sdata))

ctable = 'create table if not exists TKA (tid int , aname varchar(250))'

cu.execute(ctable)

print("table create sucessfully")

insertdata = "insert into TKA (tid , aname) values (%s, %s)"
data = [
    (1,"Roshan"),(2,"Pratik")
]

# cu.executemany(insertdata , data)

conn1.commit()

print("data insert Successfully")

select = "select * from tka"

data1 = cu.execute(select)

# print(cu.fetchone())
# print(cu.fetchone())

print(cu.fetchall())


# for i in  cu.fetchall() :
#     print(i)

cu.close()
conn1.close()
